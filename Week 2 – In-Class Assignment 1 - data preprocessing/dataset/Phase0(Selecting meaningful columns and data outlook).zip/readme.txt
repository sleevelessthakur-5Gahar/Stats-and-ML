The folder contains the dataset which has been downloaded from NASA official website.
